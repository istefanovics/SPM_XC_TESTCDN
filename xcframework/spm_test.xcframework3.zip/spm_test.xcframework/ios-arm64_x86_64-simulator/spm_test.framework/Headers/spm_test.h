//
//  spm_test.h
//  spm_test
//
//  Created by István Stefánovics on 2022. 05. 11..
//

#import <Foundation/Foundation.h>

//! Project version number for spm_test.
FOUNDATION_EXPORT double spm_testVersionNumber;

//! Project version string for spm_test.
FOUNDATION_EXPORT const unsigned char spm_testVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <spm_test/PublicHeader.h>


